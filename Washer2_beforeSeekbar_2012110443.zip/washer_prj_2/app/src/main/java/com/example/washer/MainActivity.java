package com.example.washer;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    Button washerBtn1,washerBtn2,washerBtn3,washerBtn4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        washerBtn1 = (Button) findViewById(R.id.washer1);
        washerBtn1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                onclick_washer(v,1);
            }
        });
        washerBtn2 = (Button) findViewById(R.id.washer2);
        washerBtn2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                onclick_washer(v,2);
            }
        });
        washerBtn3 = (Button) findViewById(R.id.washer3);
        washerBtn3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                onclick_washer(v,3);
            }
        });
        washerBtn4 = (Button) findViewById(R.id.washer4);
        washerBtn4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                onclick_washer(v, 4);
            }
        });

        Intent intent = getIntent();
        String usr_id = intent.getStringExtra("usr_id");
        //OOO님 환영합니다!
        String usr_password = intent.getStringExtra("usr_password");
//        String test2 = intent.getStringExtra("test2");
//        int test = intent.getIntExtra("test",0);
//        //Log.d(Integer.toString(test));
//        Log.d(TAG, Integer.toString(test) + test2);

        /*int -> default값, String -> null*/
        int hour = intent.getIntExtra("hour", -1);
        int minute = intent.getIntExtra("hour", -1);
        if (hour != -1 || minute != -1){
            //Login Activity에서 넘어오는 것을 대비하여 체크해줘야한다

        }
    }
    public void onclick_washer(View view, int washerNum) {
        Intent InputTimeIntent = new Intent(MainActivity.this, InputTime.class);
        InputTimeIntent.putExtra("washerNum",washerNum); /*송신*/
        startActivity(InputTimeIntent);
    }

}