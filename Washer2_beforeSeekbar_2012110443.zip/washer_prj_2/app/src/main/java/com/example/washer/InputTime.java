package com.example.washer;


import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Objects;

public class InputTime extends AppCompatActivity {
    private static final String TAG = "InputTime";
    Button okBtn;
    TextView washerNumTextView;
    EditText hour_text;
    EditText minute_text;
    String hour_str;
    String minute_str;
    int left_hour, left_minute;
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_time);
        //ActionBar ab = getSupportActionBar() ;
        //ab.setTitle("시간 입력");
        //ab.setDisplayHomeAsUpEnabled(true);

        washerNumTextView = (TextView) findViewById(R.id.washer_num_text);

        Intent mainIntent = getIntent();    //intent 수신
        int washerNum = Objects.requireNonNull(mainIntent.getExtras()).getInt("washerNum");
        washerNumTextView.setText(Integer.toString(washerNum) + "번 세탁기");

        okBtn = (Button) findViewById(R.id.OK_bt);
        okBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                hour_str = ((EditText)findViewById(R.id.hour_text)).getText().toString();
                minute_str = ((EditText)findViewById(R.id.minute_text)).getText().toString();
                Log.d(TAG,"minute_str : " + minute_str);
                if (!TextUtils.isEmpty(hour_str)){
                    left_hour = Integer.parseInt(hour_str);
                }
                else{
                    left_hour = 0;
                }
                if (!TextUtils.isEmpty(minute_str)){
                    left_minute = Integer.parseInt(minute_str);
                }
                else{
                    left_minute = 0;
                }
                if (left_minute == 0 && left_hour == 0){
                    Toast.makeText(getApplicationContext(), "입력된 값이 없어 자동으로 취소합니다.", Toast.LENGTH_SHORT).show();
                    return;
                }
                else{
                    Intent main_act = new Intent( InputTime.this, MainActivity.class);
                    main_act.putExtra("hour",left_hour); /*송신*/
                    main_act.putExtra("minute",left_minute); /*송신*/
                    startActivity(main_act);
                }

            }
        });


//        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
//        startActivity(intent);
    }
}